package entidade;

import java.util.Scanner;


public class CadastroAdministrador {

	private  String nome;
	private  int idade;
	private  String senha;
	private  String email;
	

	



	
	

	public CadastroAdministrador(String nome, int idade, String senha, String email) {
		super();
		this.nome = nome;
		this.idade = idade;
		this.senha = senha;
		this.email = email;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getIdade() {
		return idade;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	
	static void cadastrarADM() {
		 Scanner input = new Scanner(System.in);
		System.out.println("Digite seu Nome: ");
		String nome = input.next();
		
		System.out.println("Digite sua Idade: ");
		int idade = input.nextInt();
		
		System.out.println("Digite seu Email: ");
		String email = input.next();
		
		System.out.println("Digite sua Senha: ");
		String senha = input.next();
		
	CadastroAdministrador CadastroAdministrador = new CadastroAdministrador(nome, idade, email, senha);
	menu.cADM.add(CadastroAdministrador);

	
	System.out.println(CadastroAdministrador.getNome() + " cadastrado como Administrador!");
	
	
		menu.menu();
	
		
	}
	
	
	
	
	static void listarADM() {
		
			if (menu.cADM.size() > 0) {
				System.out.println("lista de Administradores! \n");

				for (CadastroAdministrador ca : menu.cADM) {
					System.out.println(ca);
				}
			} else {
				System.out.println("Nenhum Administrador cadastrado!");
			}
			menu.menu();
		
	}




	public String toString() {
		return "Nome: " + this.getNome() + "\nIdade: " + this.getIdade();
	}
}
	

