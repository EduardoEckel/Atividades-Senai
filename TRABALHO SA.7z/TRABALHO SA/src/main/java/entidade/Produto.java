package entidade;

import utils.Utils;
public class Produto {
	private static int count = 1;

	private int id;
	private String modelo;
	private Double preco;

	public Produto(String modelo, Double preco) {
		this.modelo = modelo;
		this.preco = preco;
		this.id = count;
		Produto.count += 1;
	}

	public int getId() {
		return id;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public Double getPreco() {
		return preco;
	}

	public void setPreco(Double preco) {
		this.preco = preco;
	}

	public String toString() {
		return "Id: " + this.getId() + "\nModelo: " + this.getModelo() + "\nPreco: "
				+ Utils.doubleToString(this.getPreco());
	}
}


