package entidade;

import java.util.Scanner;

import entidade.cadastro;
import entidade.CadastroAdministrador;
import entidade.Pessoa;
import entidade.Produto;
import utils.Utils;
import entidade.Carrinho;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;



public class menu {
	
	

		static Scanner input = new Scanner(System.in);
		static ArrayList<Produto> produtos;
		static ArrayList<CadastroAdministrador> cADM;
		static ArrayList<cadastro> clientes;
		static Map<Produto, Integer> carrinho;

		public static void main(String[] args) {
			produtos = new ArrayList<>();
			clientes = new ArrayList<>();
			cADM = new ArrayList<>();
			carrinho = new HashMap<>();
			menu();
			
			
		}
		
		
		
		static void menu() {
			System.out.println("Bem Vindo a Nossa Academia!");
			System.out.println("Seleciona uma operacao que deseja realizar");
			System.out.println("1 - Cadastrar Cliente ");
			System.out.println("2 - Cadastrar Administrador ");
			System.out.println("3 - Comprar ");
			System.out.println("4 - Carrinho ");
			System.out.println("5 - Sair ");
			System.out.println("6 - Cadastrar Produto ");
			System.out.println("7 - Listar Produtos ");
	        System.out.println("8 - Listar Clientes ");
	        System.out.println("9 - Listar Administradores ");

			int option = input.nextInt();

			switch (option) {
			
			case 1:
				
				cadastro.cadastrarCliente();
				
				
				break;
				
			case 2:
				
				CadastroAdministrador.cadastrarADM();
				
				break;
				
			
			case 9: 
				
				CadastroAdministrador.listarADM();
				
				break;
				
			case 8:
				
				cadastro.listarClientes();
				
				break;
			
			case 6:

				CadastrarProduto.cadastrarProdutos();

				break;
			case 7:
				CadastrarProduto.listarProdutos();

				break;
			case 3:
				CadastrarProduto.comprarProdutos();

				break;
			case 4:
				Carrinho.verCarrinho();

				break;
			case 5:
				System.out.println("Obrigado pela confianca!");
				System.exit(0);
			default:
				System.out.println("Opcao Invalida!");
				menu();
				break;

			}

		}
		
}
