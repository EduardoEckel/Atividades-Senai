package entidade;

public class Pessoa {

	private  String nome;
	private  String dataNasc;
	private  String email;
	private  String senha;
	
	public Pessoa(String nome, String dataNasc, String email, String senha) {
		super();
		this.nome = nome;
		this.dataNasc = dataNasc;
		this.email = email;
		this.senha = senha;
	}
	
	public Pessoa(String email, String senha) {
		super();
		this.email = email;
		this.senha = senha;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getDataNasc() {
		return dataNasc;
	}
	public void setDataNasc(String dataNasc) {
		this.dataNasc = dataNasc;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	
	

}
