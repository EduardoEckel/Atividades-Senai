package entidade;

import java.util.Scanner;


import utils.Utils;

public class CadastrarProduto  {
	
	


	
	
static void cadastrarProdutos() {
	Scanner input = new Scanner(System.in);
	if (menu.cADM.size() > 0) {
		System.out.println("lista de Administradores! \n");

		for (CadastroAdministrador ca : menu.cADM) {
			System.out.println(ca);
		}
		
		System.out.println("Qual o seu email? \n");
		  String emaill = input.next();
		 
		 System.out.println("Qual o seu senha? \n");
		  String senhaa = input.next();
		 
		 if(menu.cADM.size() > 0) {
			 for(CadastroAdministrador ca : menu.cADM) {
				 if(ca.getEmail() == emaill && ca.getSenha() == senhaa) {
					 System.out.println("Login Encontrado! \n");
				 }else {
						System.out.println("Nenhum Administrador cadastrado!");
						menu.menu();
				 System.out.println("Login autorizado! \n");
				 
			 }
					System.out.println("Modelo do produto: ");
					String modelo = input.next();

					System.out.println("Preco do produto: ");
					Double preco = input.nextDouble();

					Produto produto = new Produto(modelo, preco);
					menu.produtos.add(produto);

					System.out.println(produto.getModelo() + " cadastrado com suceso!");
					menu.menu();
		 } 
	}
	}
}

	

	static void listarProdutos() {
		 Scanner input = new Scanner(System.in);
		if (menu.produtos.size() > 0) {
			System.out.println("lista de produtos! \n");

			for (Produto p : menu.produtos) {
				System.out.println(p);
			}
		} else {
			System.out.println("Nenhum produto encontrado!");
		}
		menu.menu();
	}

	 static void comprarProdutos() {
		if (menu.produtos.size() > 0) {
			System.out.println("Codigo do produto: \n");

			System.out.println("Produtos disponiveis");
			for (Produto p : menu.produtos) {
				System.out.println(p + "\n");
			}
			int id = Integer.parseInt(menu.input.next());
			boolean isPresent = false;

			for (Produto p : menu.produtos) {
				if (p.getId() == id) {
					int qtd = 0;
					try {
						qtd = menu.carrinho.get(p);
						menu.carrinho.put(p, qtd + 1);
					} catch (NullPointerException e) {
						menu.carrinho.put(p, 1);
					}

					System.out.println(p.getModelo() + " adicionado ao carrinho.");
					isPresent = true;

					if (isPresent) {
						System.out.println("Deseja adicionar outro produto? ");
						System.out.println("Digite 1 para sim, ou 0 para finalizar a comrpa. \n");
						int option = Integer.parseInt(menu.input.next());

						if (option == 1) {
							comprarProdutos();
						} else {
							finalizarCompra();
						}
					}
				} else {
					System.out.println("Produto nao encontrado.");
					menu.menu();
				}
			}
		} else {
			System.out.println("Nao existem produtos cadastrados!");
		}
	}



private static void finalizarCompra() {
	Double valordaCompra = 0.0;
	System.out.println("Seus Produtos!");

	for (Produto p : menu.carrinho.keySet()) {
		int qtd = menu.carrinho.get(p);
		valordaCompra += p.getPreco() * qtd;
		System.out.println(p);
		System.out.println("Unidades: " + qtd);
		System.out.println("\n");

	}
	System.out.println("O valor da sua compra é: " + Utils.doubleToString(valordaCompra));
	menu.carrinho.clear();

	System.out.println("Volte sempre!");
	menu.menu();
}
}
