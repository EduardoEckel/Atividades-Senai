package entidade;

public class Carrinho {
	static void verCarrinho() {
		System.out.println("Produtos no carrinho!");
		if (menu.carrinho.size() > 0) {
			for (Produto p : menu.carrinho.keySet()) {
				System.out.println("Produto: " + p + "\nUnidade: " + menu.carrinho.get(p));
			}

		} else {
			System.out.println("carrinho vazio!");
			menu.menu();
		}
	}
}
