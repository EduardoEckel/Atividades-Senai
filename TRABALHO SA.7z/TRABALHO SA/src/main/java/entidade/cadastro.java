package entidade;

import java.util.Scanner;

public class cadastro {

	private  String nome;
	private  int idade;
	private  float altura;
	private  float peso;
	private  String senha;
	private  String email;
	
	

	

	public cadastro(String nome, int idade, float altura, float peso, String senha, String email) {
		
		this.nome = nome;
		this.idade = idade;
		this.altura = altura;
		this.peso = peso;
		this.senha = senha;
		this.email = email;
	}


	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public float getAltura() {
		return altura;
	}

	public void setAltura(float altura) {
		this.altura = altura;
	}

	public float getPeso() {
		return peso;
	}

	public void setPeso(float peso) {
		this.peso = peso;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	
	static void cadastrarCliente() {
		Scanner input = new Scanner(System.in);
		System.out.println("Digite seu Nome: ");
		String nome = input.next();
		
		System.out.println("Digite sua Idade: ");
		int idade = input.nextInt();
		
		System.out.println("Digite sua Altura: ");
		float altura = input.nextFloat();
		
		System.out.println("Digite seu Peso: ");
		float peso = input.nextFloat();
		
		System.out.println("Digite seu Email: ");
		String email = input.next();
		
		System.out.println("Digite sua Senha: ");
		String senha = input.next();
		
		cadastro cadastro = new cadastro(nome, idade, altura, peso, senha, email);
		
		menu.clientes.add(cadastro);
		
		System.out.println(cadastro.getNome() + " cadastrado como cliente!");
		
		
		menu.menu();
	
		
	}
	
	
	static void listarClientes() {
		
			if (menu.clientes.size() > 0) {
				System.out.println("lista de clientes! \n");

				for (cadastro c : menu.clientes) {
					System.out.println(c);
				}
			} else {
				System.out.println("Nenhum cliente cadastrado!");
			}
			
		menu.menu();
	}



	public String toString() {
		return "Nome: " + this.getNome() + "\nIdade: " + this.getIdade() + "\nAltura: " + this.getAltura() + "\nPeso: "
				+ this.getPeso() + "\nEmail: " + this.getEmail() + "\nSenha: " + this.getSenha();

	}
}
