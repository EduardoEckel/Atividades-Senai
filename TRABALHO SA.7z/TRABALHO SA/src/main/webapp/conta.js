let Nomec = localStorage.getItem('nome-cliente');
let Planoc = localStorage.getItem('plano-cliente');

console.log(Nomec)

document.getElementById('nomec').innerText = Nomec;
document.getElementById('planoc').innerText = Planoc;

