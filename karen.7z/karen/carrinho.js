let qtddd = localStorage.getItem('qtd-whey')
let qtddc = localStorage.getItem('qtd-creatina')
let valorW = localStorage.getItem('qtd-whey') * 99.00;
let valorC = localStorage.getItem('qtd-creatina') * 54.99;
let Total = valorW + valorC;

document.getElementById('qtdd').innerText = "Quantidade: "+ qtddd;
document.getElementById('qtdc').innerText = "Quantidade: "+ qtddc;
document.getElementById('valor').innerText = "Valor: "+Total;