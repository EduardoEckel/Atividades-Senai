function confirmar() {
    let Nome = document.getElementById('nomee').value;
    let Data = document.getElementById('nasc').value;
    let Email = document.getElementById('email').value;
    let Peso = document.getElementById('peso').value;
    let Altura = document.getElementById('altura').value;
    let Senha = document.getElementById('senha').value;
    let Plano = document.getElementById('planoo').value;

    console.log(Nome)

    if (Nome != '' || Data != '' || Email != '' || Peso != '' || Altura != '' || Senha != '' || Plano != '') {
        document.getElementById('resultado').innerText = 'Cadastro Realizado'
    } else {
        document.getElementById('resultado').innerText = 'Cadastro Invalido'
    }

    
    localStorage.setItem('nome-cliente', Nome)
    localStorage.setItem('data-cliente', Data)
    localStorage.setItem('email-cliente', Email)
    localStorage.setItem('peso-cliente', Peso)
    localStorage.setItem('altura-cliente', Altura)
    localStorage.setItem('senha-cliente', Senha)
    localStorage.setItem('plano-cliente', Plano)
}