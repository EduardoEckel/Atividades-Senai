var qtd = 0;
function add() {
  qtd++;
localStorage.setItem('qtd-whey', qtd)
}