var qtd = 0;
function add() {
  qtd++;
localStorage.setItem('qtd-creatina', qtd)
}