package Programa;

public class Pessoa {

private static int counter = 1;
	
private String nome;
private String cpf;
private String email;
private String endereço;
private String renda;
private String profissao;

public Pessoa(String nome, String email, String cpf, String endereço, String renda, String profissao) {
	this.nome = nome;
	this.cpf = cpf;
	this.email = email;
	this.endereço = endereço;
	this.renda = renda;
	this.profissao = profissao;
	counter += 1;
}
public String getNome() {
	return nome;
}
public void setNome(String nome) {
	this.nome = nome;
}
public String getCPF() {
	return cpf;
}
public void setCPF(String cPF) {
	cpf = cPF;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getEndereço() {
	return endereço;
}
public void setEndereço(String endereço) {
	this.endereço = endereço;
}
public String getRenda() {
	return renda;
}
public void setRenda(String renda) {
	this.renda = renda;
}
public String getProfissao() {
	return profissao;
}
public void setProfissao(String profissao) {
	this.profissao = profissao;
}

public String toString() {
	return "\nNome: " + this.getNome() +
			"\nCPF: " + this.getCPF() +
			"\nEmail: " + this.getEmail()+
			"\nProfissao: " + this.getProfissao()+
			"\nRenda: " + this.getRenda()+
			"\nEndereço: " + this.getEndereço();
}

}








